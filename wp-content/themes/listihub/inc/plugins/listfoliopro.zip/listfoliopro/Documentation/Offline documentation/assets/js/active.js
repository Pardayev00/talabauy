(function ($) {
    "use strict";
	
	$(document).ready(function() {

       $("#document-nav").scrollspy({
       		activeClass: 'active',
       		offset: 0,
       		animate: true
       });
	   
	});
})(jQuery);